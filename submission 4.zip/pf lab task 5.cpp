 #include<iostream>
using namespace std;


int main(){
int day;
//representing the days 
cout<<"enter a number to represent the days of week"<<endl;
cout<<"1-Monday"<<endl;
cout<<"2-Tuesday"<<endl;
cout<<"3-Wednesday"<<endl;
cout<<"4-Thursday"<<endl;
cout<<"5-Friday"<<endl;
cout<<"6-Saturday"<<endl;
cout<<"7-Sunday"<<endl;
cout<<"Enter your choice";
cin>> day;
//in switch satement
switch(day){
	case1:
	cout<<"Monday:Start of the work week"<<endl;
	break;
	case2:
	cout<<"Tuesday:Stay poitive"<<endl;
	break;
	case3:
	cout<<"Wednesday:Mid-week motivation"<<endl;
	break;
	case4:
	cout<<"Thursday: Alomost the weekend"<<endl;
	break;
	case5:
	cout<<"Friday:TGIF-Thank God its Friday!"<<endl;
	break;
	case6:
	cout<<"Saturday:Relax and enjoy"<<endl;
	break;
	case7:
	cout<<"Sunday:Enjoy your Sunday"<<endl;
	break;
	default:
	cout<<"Wrong selection please choosen the number between 1 and 7 for days of week "<<endl;
	break;
	return 0;
}

	return 0;
}

