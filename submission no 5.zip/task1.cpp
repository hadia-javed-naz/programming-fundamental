#include<iostream>
using namespace std;
int main()
{
	int number,i;
	 cout<<"Enter a number:"<<endl;
	    cin>>number;
	for(i=1;i<=10;i++){
		cout<<number<<"*"<<i<<"="<<number*i<<endl;
	}
	return 0;
}