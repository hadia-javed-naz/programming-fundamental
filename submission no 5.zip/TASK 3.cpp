#include<iostream>
using namespace std;
int main()
{
	int number,sum=0;
	cout<<"enter the number:";
	while(true){
		cin>>number;
		sum=sum+number;
		if(number<0){
			break;
		}
		sum=sum+number;
	}
		cout<<"total sum of all negative number:"<<sum;
		return 0;
}