#include<iostream>
using namespace std;
int main()
{
	int number,i=1,sum=0;
	cout<<"Enter a number:";
	cin>>number;
	while(i<=number){
	sum=sum+i;
	i+=2;
}
	cout<<"The sum of all odd number "<<number<<"is"<<sum;
}