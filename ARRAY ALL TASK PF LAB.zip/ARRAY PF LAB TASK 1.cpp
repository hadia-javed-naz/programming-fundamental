#include <iostream>
using namespace std;

int main() {
    const int SIZE = 3;
    int numbers[SIZE];

   
    cout << "Enter three integer values:" << endl;
    for (int i = 0; i < SIZE; i++) {
        cout << "Value " << i + 1 << ": ";
        cin >> numbers[i];
    }


    cout << "\nValues in forward order: ";
    for (int i = 0; i < SIZE; i++) {
        cout << numbers[i] << " ";
    }

    
    cout << "\nValues in reversed order: ";
    for (int i = SIZE - 1; i >= 0; i--) {
        cout << numbers[i] << " ";
    }

    return 0;
}
