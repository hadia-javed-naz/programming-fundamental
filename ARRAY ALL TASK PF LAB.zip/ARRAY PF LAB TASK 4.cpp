#include<iostream>
#include<string>
using namespace std;

int main() {
int entryFee = 20; 
int snackCost = 10; 
int n;              
double totalCost = 0;  
string names[15];      
cout<<"How many students will attend the game night? (Maximum 15):";
cin>>n;
if(n>15)
{
cout<<"Error: Not more students allowed."<<endl;
} 
else
{
cout<<"The number of students attending the event is:"<<n<<endl;
for(int i=1; i<=n; i++) 
{
cout<<"Enter name for student "<<i<<":";
cin>>names[i];
}
 cout<<"User names for the event:"<<endl;
for(int l=1; l<=n; l++) 
{
cout<<"User"<<l<<":"<<names[l]<<endl;
}
for(int k=1; k<=n; k++)
 {
double individualCost=entryFee+snackCost;
totalCost+=individualCost;
cout<<"The total cost for student"<<names[k]<<"is"<< individualCost<<endl;
}
cout<<"Total cost for all "<<n<<"students is:"<<totalCost<<endl;}
return 0;
}

