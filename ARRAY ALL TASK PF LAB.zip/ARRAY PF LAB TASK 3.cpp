#include<iostream>
#include<string>
using namespace std;

int main() 
{
int popcorn = 50;  
int ticket = 100;  
double totalsum = 0;  
string nam[10];  
int n; 
int m;  
cout<<"How many students want to attend the event? (max: 10)"<<endl;
cin>>n;
if(n>10) 
{
cout<<"Error! Not more than 10 users allowed."<<endl;
} 
else 
{
cout<<"The number of students attending the event is:"<<n<<endl;
for(int i=1; i<=n; i++) 
{
cout<<"Enter name for student"<<i<< ": ";
cin>>nam[i];
}
cout<<"User names for the event:"<<endl;
for(int j=1; j<=n; j++) 
{
cout<<"User"<<j<<":"<<nam[j]<<endl;
}
for(int l=1; l<=n;l++)
{
m=ticket+popcorn;  
totalsum+=m;  
cout<<"The total cost for student "<<nam[l]<<"is"<<m<<endl;
 }
cout<<" Total cost  for all "<<n<<"users is:"<<totalsum<<endl;
}
return 0;
}

