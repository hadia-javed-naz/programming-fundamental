#include <iostream>
using namespace std;
int main()
{
for (int i = 2; i <= 20; i += 3) {
cout<<i<< " ";
}
return 0;
}
