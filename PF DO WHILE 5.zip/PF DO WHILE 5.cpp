#include <iostream>
using namespace std;
int main()
{
int N,sum = 0;
cout<<"Enter the value of N:"<<endl;
cin>>N;
for(int i = 1; i <= N; i++)
{
sum += i * i;
}
cout << "The sum of squares of the first:"<< N <<"natural numbers is:"<< sum<< endl;
return 0;
}
