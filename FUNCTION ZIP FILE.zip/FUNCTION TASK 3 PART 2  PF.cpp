#include <iostream>
using namespace std;


void cubeByReference(int &n, int &result) {
    result = n * n * n;
}

int main() {
    int num, result;

    cout << "Pass by Reference: Enter integers to calculate their cube (0 to exit):" << endl;
    while (true) {
        cin >> num;
        if (num == 0) 
            break;
        cubeByReference(num, result);
        cout << "Cube of " << num << " is: " << result << endl;
    }

    cout << "Program terminated (Pass by Reference)." << endl;
    return 0;
}
