#include<iostream>
using namespace std;
int largestvalue(int a,int b,int c){
	int largest=a;
	if(b>largest){
	largest=b;
	}
	if(c>largest){
	largest=c;
	}
	return largest;
    }
	int main(){
	int x,y,z;
	cout<<"Enter three integers:";
	cin>>x>>y>>z;
	int largest= largestvalue(x,y,z);
	cout<<"The largest value integer is: "<<largest;
	return 0;
	}