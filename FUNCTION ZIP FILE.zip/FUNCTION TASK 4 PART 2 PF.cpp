#include <iostream>
using namespace std;

void printTempOpinion(const int &temp) {
    if (temp < 10)
        cout << "Cold" << endl;
    else if (temp >= 20 && temp <= 30)
        cout << "OK" << endl;
    else if (temp > 30)
        cout << "Hot" << endl;
    else
        cout << "Temperature not in the specified range" << endl;
}

int main() {
    int temperature;

    cout << "Enter temperature (Pass by Reference): ";
    cin >> temperature;

    printTempOpinion(temperature);  

    return 0;
}
