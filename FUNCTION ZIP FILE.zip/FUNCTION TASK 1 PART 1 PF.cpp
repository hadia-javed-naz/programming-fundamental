#include <iostream>
using namespace std;
void swap_num(int a,int b)
{
	int temp = a;
    a=b;
	b=temp;
	cout<<"The value after swap of a:"<<a<<endl<<"the value after swap of b:"<<b<<endl;
}

int main() {
    int c=20;
    int d=30;
    swap_num(c,d);

    return 0;
}
