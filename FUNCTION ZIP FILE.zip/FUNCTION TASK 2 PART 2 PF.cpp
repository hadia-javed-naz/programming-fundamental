//pass by reference
#include <iostream>
using namespace std;
void largestnum(int &a,int &b,int &c,int &largest) {
    largest = a;
    if (b>largest) {
    largest=b;
    }
    if (c>largest) {
    largest=c;
    }
}

int main() {
    int x,y,z,largest;
    cout << "Enter three integers: ";
    cin>>x>>y>>z;
    largestnum(x,y,z,largest);
    cout << "The largest integer is: " <<largest<<endl;
    return 0;
}