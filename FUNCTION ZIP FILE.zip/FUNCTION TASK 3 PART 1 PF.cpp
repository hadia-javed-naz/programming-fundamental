#include <iostream>
using namespace std;

int cubeByValue(int n) {
    return n * n * n;
}

int main() {
    int num;

    cout << "Pass by Value: Enter integers to calculate their cube (0 to exit):" << endl;
    while (true) {
        cin >> num;
        if (num == 0)  
            break;
        cout << "Cube of " << num << " is: " << cubeByValue(num) << endl;
    }

    cout << "Program terminated (Pass by Value)." << endl;
    return 0;
}
